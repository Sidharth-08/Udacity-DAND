
# Data Visualization
##### by Sidharth Suman



### **Introduction**

An attempt has been made to create an explanatory data visualization from a baseball data set that communicates the findings about the relationships or patterns in the provided data. Tableau framework has been used to create the visualization and find new insights about the performance of the baseball players. 

**First Visualization** *:- https://public.tableau.com/profile/sidharth.suman#!/vizhome/2_Data_Viz_Project/Story1  *

**Final Visualization** *:- https://public.tableau.com/profile/sidharth.suman#!/vizhome/FinalData_Viz_Project/Story1  *

___

### **Summary**

During the course of making this data visualization various Tableau techniques were used to represent Baseball data. Many relationships have been explored within the factors such as Batting Average and Height and Weight. A new variable i.e Height/Weight ratio was used to explore new insights. 

*In conclusion, it was found that a player weighing aproximatly 180 pounds and having height of 72 to 74 inches is predicted to perform better than other players in the same set of circumstances, without any effect of left or right handedness of the player.*


### **Design**
The X and Y axis headers were used in both the designs and some new variables were introduced in the final design.

**Initial Design**
```
Initially the chart type and format settings for all the axis and plots were set to default, and each plot contained 
gridlines and labels.No changes were made to any variables and no new variables were introduced.The charts were able 
to show the results clearly. 

A point in a normal distribution plot of Height and Home Runs was "Annotated" as to show the findings. A "Handedness" 
filter was used to show the results,although the changes in the right and left handedness were not significant as the 
difference in the results was clearly due to difference in the number of records with each handedness(R, L and B).

X and Y axis of all plots were shown with no color encoding being done as it wasn't felt needed.
```

**Final Design**
```
The grid lines were removed from plots except scatter plot as they weren't needed and decreased the data-ink ratio.There were two "Calculated Fields" introduced i.e the "Ht Wt Ratio" and the "Ht Wt Ratio(bins)" as they allowed to analyze the data indepth and made a way for bar plots. 

The "Handedness" filter was also used with the color legend for showing the color encoding in a plot.

Color encoding was used to signify the difference in handedness but color-blindness was looked upon and the use of red & green combination was avoided at all costs. Highlights were added so that the reader can know data well. Some annotation were used to signify important points. Comments in stories were made more understandable and comprehensive.
```
### **Feedback**

* The story/ final visualization did not have a title.

>You need to have a title so I know what the graphs are about.

* Everything felt somewhat cramped up and tight making it hard to relate to the graphs.

>All the plots are squeezed together and it's hard to make out the meaning of plots.

* Unable to understand the meaning of HR and Avg

>What is HR and which average is Avg?

* Why did you make seperate Height/Weight plots and not took a ratio ?

>First, I look at seperate Ht measures and then at Weight measures which won't show anything as different ht people can have same wt.

* The filter was not really visible and got mixed up with everything could not be found.

>The filter has no border and is white background dialog box, how do you expect me to see it when I can't figure out meaning of plots.

* Visualizations not described properly in the public profile.

>Again, What is the visualization about students, doctors, birds ?

* Hard to make out the meaning of graphs.

>So less space.

* Name your axis properly.

>Give them a meaning and not just a technical term.

### **Resources**
1. https://onlinehelp.tableau.com/current/pro/desktop/en-us/publish_workbooks_tableaupublic.html
2. https://www.tableau.com/learn/training
3. https://community.tableau.com/thread/137413
4. http://onlinehelp.tableau.com/v10.4/pro/desktop/en-us/help.htm#extracting_data.html
5. https://www.youtube.com/watch?v=znV12jYDyB0
6. https://github.com/liu1000/p6-data-viz


