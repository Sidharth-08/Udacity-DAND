# Udacity-DAND-Tableau-Story-of-Baseball-Players
A Data visualization using Tableau that tells a story about the physical factors affecting the performance of baseball players.

### Introduction

An attempt has been made to create an explanatory data visualization from a baseball data set that communicates the findings about the relationships or patterns in the provided data. Tableau framework has been used to create the visualization and find new insights about the performance of the baseball players. 


First Visualization :- https://public.tableau.com/profile/sidharth.suman#!/vizhome/2_Data_Viz_Project/Story1 

Final Visualization :- https://public.tableau.com/profile/sidharth.suman#!/vizhome/FinalData_Viz_Project/Story1 

### Summary

During the course of making this data visualization various Tableau techniques were used to represent Baseball data. Many relationships have been explored within the factors such as Batting Average and Height and Weight. A new variable i.e Height/Weight ratio was used to explore new insights. 
In conclusion, it was found that a player weighing aproximatly 180 pounds and having height of 72 to 74 inches is predicted to perform better than other players in the same set of circumstances, without any effect of left or right handedness of the player.
