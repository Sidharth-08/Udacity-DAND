# Udacity DAND Inferential Statistics

### Abstract

The stroop effect, names after American psychologist John Ridley Stroop is a psychological occurrence that describes results of an interference in reaction time of a task. A demonstration of such an occurance can be found here . Stroop Effect, in a layman's term can be described as a demonstration of interference in the reaction time of a task. It is often demonstrated by the well known Stroop Effect Experiment .



### Stoop Effect Experiment

In a Stroop task, participants are presented with a list of words, with each word displayed in a color of ink.The task has two conditions: a congruent words condition, and an incongruent words condition.In the Congruent words condition, the words being displayed are color words whose names match the colors in which they are printed: for example RED, BLUE.In the Incongruent words condition, the words displayed are color words whose names do not match the colors in which they are printed: for example PURPLE, ORANGE.In each case, we measure the time it takes to name the ink colors in equally-sized lists. Each participant will go through and record a time from each condition.

* Step 1 : Participants are shown the samples of Congruent words.
* Step 2 : The participant’s task is to say out loud the color of the ink in which the word is printed as fast as they can while the time taken to say the color is recorded.
* Step 3 : The time taken to say the color out loud is recorded and both step 1 and 2 recorded with an Incongruent samples and the time is recorded for the Incongruent samples as well.
The above steps are repeated with a large number of population and then the time taken by people is recorded and analysed for the stroop effect.

### Goal Of The Experiment

As per the Stroop Effect, the population of participants in experiment recorded aa longer reaction time when performing the experiment with a sample of incongruent words and colors. In other words, if the color in which words are printed do not match name of the color printed, it takes more time for us to process this difference and then give the right answer. Here, we have attempted to perform a statistical test on sample of participants to predict the outcome of entire population of participants, who undergo the stroop test experiment. Henceforth, deciding whether stroop effect indeed interferes with or changes the normal response time of people.


Final project file - `Inferential_Project.ipynb`
