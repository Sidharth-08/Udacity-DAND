# Udacity DAND Investigating Titanic dataset

### Investigate a DataSet : Titanic

I have made an attempt to analyze the Titanic dataset hosted on the Kaggle website.
The dataset contains classification on the basis of survival, fare, gender, family on board and many other criteria of knowledge of 891 passengers from the total 2224 passengers that were on board Titanic when the fatal disaster took place. It is my idea that analyzing this data could provide us with an in-depth knowledge of how human psychology works at a time of chaos and actions that people take when in an unforeseen situation with no formal training and guided only by their survival instincts.
