getwd()
list.files()
bday<-read.csv('facebook_birthday.csv',stringsAsFactors = FALSE)   
                                                          #
                                                          #because we don't want factors and levels

#removing Duration and End column
names(bday)

library(dplyr)
bday<-select(bday,Title,Start)
head(bday)

str(bday)

bday$Start<-as.Date(bday$Start,'%m/%d/%y')

bday$month<-format(bday$Start,'%m')
bday$day<-format(bday$Start,'%d')

bday<-select(bday,-Start)

head(bday)

bday<-arrange(bday,month,day)
bday<-filter(bday,!is.na(bday$month),!is.na(bday$day))

#month-------------------------------------
bday_month<-group_by(bday,month)


bday_month<-summarise(bday_month,count=n())

qplot(data=bday,x=month,color=I('black'),fill=I('dark blue'),
     xlab=('Months in an Year'),ylab=('Number of Birthdays'))
ggsave('plot1.png')
  
bday_month

qplot(data=bday_month,x=month,y=count,color=I('dark blue'))
ggsave('plot2.png')



#day-------------------------------------  
bday_day<-group_by(bday,day)
bday_day<-summarise(bday_day,count=n())

qplot(data=bday,x=day,color=I('black'),fill=I('dark blue'),
      xlab=('Days from 1 to 31'),ylab=('Number of Birthdays'))

ggsave('plot3.png')

qplot(data=bday_day,x=day,y=count,xlab=('Days from 1 to 31'),ylab=('Number of Birthdays'))
ggsave('plot4.png')


#facet---------------------
qplot(data=bday,x=day,color=I('black'),fill=I('dark blue'),
      xlab=('Days'),ylab=('Number of Birthdays'))+
  facet_wrap(~month,scales = 'fixed')
ggsave('plot5.png')

same<-subset(bday,bday$month=='09' & bday$day=='08')
same

