# Udacity-Facebook-friends

Analyzing facebook friends' birthdays to find new insights about people in my network.

Framework used: R Studio

Main project file: facebook_friends.R
