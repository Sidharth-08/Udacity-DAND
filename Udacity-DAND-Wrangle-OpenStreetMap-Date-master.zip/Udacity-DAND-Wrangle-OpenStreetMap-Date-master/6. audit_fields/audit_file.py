import xml.etree.cElementTree as ET
from collections import defaultdict
import re
import pprint
from datetime import datetime

osm_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\new-delhi_india.osm'         # original dataset take from open street map
sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\sample.osm'               # sample file with a portion of data set
small_sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\small_sample.osm'   # a smaller sample file for testing purposes

field_type_re = re.compile(r'\b\S+\.?$', re.IGNORECASE)                                # regular expression to check street type
year_re = re.compile(r'.*([1-3][0-9]{3})', re.IGNORECASE)                              # regular expression to check year
now=datetime.now()                                                                     # to get current datetime

expected = ["Street", "Avenue", "Boulevard", "Drive", "Court", "Place", "Square", "Lane", "Road",
            "Trail", "Parkway", "Commons",'Area','Bazaar','Circus','Enclave','Estate','Kaushambi',
            'Marg','NIT','Nagar','Yojna','Vasundhara','Sector-56','Vihar','Wali','mandawali','Part-A']


'''
In the Update variable for operator names
we have tried to filter the operator
on the basis of their buisnesses
but proper auditing can not be done due
to too much variety of data forms and garbage data involved
'''


operator_mapping={                                                              # Update variable for operator names
        'stand':'stand,company',
        'station':'station, company',
        'mall':'mall, company',
        'http://antiwrinkleadvice.com/':'antiwrinkleadvice, company',
        'hdfc':'hdfc, bank',
        'fjjdi':'',
        'akgec':'',
        'TLD':'TLD, company',
        'abc':'',
        'Taj':'Taj, company',
        'Tata-Fiat':'Tata-Fiat, company',
        'Town':'Town, company',
        'Trident':'Trident, company',
        'VITA': 'VITA, company',
        'Vidyalaya':'Vidyalaya, school',
        'Wears': 'Wears, company',
        'Worldwide': 'Worldwide, company',
        'icici':'icici, bank',
        'icic':'icici, bank',
        'vihar':'vihar, ngo',
        'lounge':'lounge, company',
        'singh':'singh, worker',
        'shop':'shop, company',
        'sbi':'sbi, bank',
        'sahiljat':'sahiljat, employee',
        'rooms':'rooms, company',
        'plaza':'plaza, company',
        'rohini':'rohini, bank'
}

city_mapping={                                                                  # Update variable for city names
        'unknown':'',
        'survey':'',
        'ad':'',
        'AD':'',
        'U.P)':'Uttar Pradesh',
        'Sohna-Gurgaon':'Gurgaon',
        'NOIDA':'Noida',
        'noida':'Noida',
        'meerut':'Meerut',
        'Delh': 'Delhi',
        'bangalore':'Bangalore',
        'delhi': 'Delhi',
        'DELHI': 'Delhi',
        'Dwarka': 'Delhi',
        'faridabad': 'Faridabad',
        'ghaziabad': 'Ghaziabad',
        'Ghazaibad': 'Ghaziabad',
        'Ghaziabazd':'Ghaziabad',
        'hyderabad':'Hyderabad',
        'MW':'Meerut',
        'Gurgram':'Gurugram'

}

mapping = { "St": "Street",                                                     # Update variable for street names
            "St.": "Street",
            'Rd.':'Road',
            'Ave':'Avenue',
            'Delhi-110089':'Delhi',
            'Delhi-110021':'Delhi',
            'II':'Phase 2',
            'III':'Phase 3',
            'Indirapuram':'',
            'dilli':'New Delhi',
            'Extn':'Extension',
            'S1':'',
            'Fram':'Farm',
            'Gaziabad':'Ghaziabad',
            'Indra':'Noida',
            'Kailash-1':'Kailash',
            'Kaushambu':'Kaushambi',
            'sdf':'SDF',
            'Ln':'Lines',
            'up':'Uttar Pradesh',
            'U.P)':'Uttar Pradesh',
            'UP':'Uttar Pradesh',
            'UP)':'Uttar Pradesh',
            'Vasundhara':'Vasundhra',
            'delhi':'Delhi',
            'ph-1':'Phase 1',
            'Marg,':'Marg',
            'p':'P',
            'Mg':'Marg',
            'marg':'Marg',
            'NOIDA':'Noida',
            'Noida,':'Noida',
            'noida':'Noida',
            'Park)':'Park',
            'Pritampura':'Pitampura',
            'Rd':'Road',
            'Road,':'Road',
            'road':'Road',
            'Rohini,Delhi':'Rohini',
            'Saidulajab,':'Saidulajab',
            'Sec-8':'Sector-8',
            'sector39':'Sector-39',
            'Sector-%':'',
            'Bazar':'Bazaar',
            'plaza':'Plaza',
            'A1':'A-1'
            }

name_mapping={                                                                  # Update variable for street names
            'Apartment':'Apartments',                                           # most of the name data is non auditable
            'BUILDING':'Building',                                              # due to use of Hinglish Language
            'Building.':'Building',
            'BUILDING)':'Building',
            'Bhavan':'Bhawan',
            'Chowki':'Station',
            'Deli':'Delhi',
            'Del\xed':'',
            'Dill\xed':'',
            'Del\u0117s':'',
            'D\xe9hli':'',
            'Dilhi':'Delhi',
            'Extn':'Extension',
            'Extn.':'Extension',
            'Nieu-Delhi':'New-Delhi',
            "Nueva Delhi":'New-Delhi',
            "Nacdjd Delhi":"New Delhi",
            "'f'swfl@$646'":"New Delhi"
}

def is_garbage_value(field_name):                                               # to detect garbage values in xml
    return (field_name==None)

def update_single(field_name,value):                                            # update function for direct value assignment
    field_name=value

def update_mapping(field_name,mapping,m):
    if(m.group() in mapping):
        field_name=re.sub(m.group(), mapping[m.group()], field_name)

def audit_field_type(field_types, field_name,field):
    if(field=='post'):
        if(len(str(field_name))<6):                                             # if post code is not a bad value
            update_single(field_name,'110001')                                  # we change it to post code of central Delhi
            add_to_dict(field_name,field_types)
        else:
            add_to_dict(field_name,field_types)

    if(field=='population'):
        if(int(float(field_name))<=int(now.year)):                              # checking if population is valid
            update_single(field_name,None)                                      # if population is a bad value
            add_to_dict(field_name,field_types)                                 # we change it to None, so that we can remove it
        else:
            add_to_dict(field_name,field_types)

    if(field=='city'):                                                          # auditing city names
        m = field_type_re.search(field_name)
        if m:
            update_mapping(field_name,city_mapping,m)
            m = field_type_re.search(field_name)
            if m != None:
                field_matcher = m.group()
                field_types[field_matcher].add(field_matcher)
            else:
                field_types['Garbage'].add(field_name)

    if(field=='street'):                                                        # auditing street names
        m = field_type_re.search(field_name)
        if m:
            if m.group() not in expected:
                update_mapping(field_name,mapping,m)
                m = field_type_re.search(field_name)
                if m != None:
                    field_matcher = m.group()
                    field_types[field_matcher].add(field_matcher)
                else:
                    field_types['Garbage'].add(field_name)

    if(field=='operator'):                                                      # auditing operator names
        m = field_type_re.search(field_name)
        if m:
            update_mapping(field_name,operator_mapping,m)
            m = field_type_re.search(field_name)
            if m != None:
                field_matcher = m.group()
                field_types[field_matcher].add(field_matcher)
            else:
                field_types['Garbage'].add(field_name)

    if(field=='name'):                                                          # auditing names
        m = field_type_re.search(field_name)
        if m:
            update_mapping(field_name,name_mapping,m)
            m = field_type_re.search(field_name)
            if m != None:
                field_matcher = m.group()
                field_types[field_matcher].add(field_matcher)
            else:
                field_types['Garbage'].add(field_name)


def add_to_dict(field_name,field_types):
    if(field_name != None):
        m = field_type_re.search(field_name)
        if m:
            field_match=m.group()
            field_types[field_match].add(field_name)
    else:
        field_types['Garbage'].add(field_name)


def is_field_name(elem,field):
    return ( field in elem.attrib['k'])


def audit(osmfile,field):
    osm_file = open(osmfile, "r")
    field_types = defaultdict(set)
    for event, elem in ET.iterparse(osm_file, events=("start",)):

        if elem.tag == "node" or elem.tag == "way":
            for tag in elem.iter("tag"):
                if is_field_name(tag,field):
                    audit_field_type(field_types, tag.attrib['v'],field)
    osm_file.close()
    return field_types


with open('audit_file_output.txt','w') as f:
    post_types = audit(sample_file,'post')                                      # auditing postal codes
    f.write('Audited and updated postal codes are: \n')
    f.write(str(post_types))
    population_types=audit(sample_file,'population')                            # auditing population
    f.write('\n\nAudited and updated population fields are: \n')
    f.write(str(population_types))
    street_types=audit(sample_file,'street')                                    # auditing street types
    f.write('\n\nAudited and updated street type fields are: \n')
    f.write(str(street_types))
    city_types=audit(sample_file,'city')                                        # auditing city types
    f.write('\n\nAudited and updated city type fields are: \n')
    f.write(str(city_types))
    operator_types=audit(sample_file,'operator')                                # auditing operator types
    f.write('\n\nAudited and updated operator type fields are: \n')
    f.write(str(operator_types))
    name_types=audit(sample_file,'name')                                        # auditing name types
    f.write('\n\nAudited and updated name type fields are: \n')
    f.write(str(name_types))
