import xml.etree.cElementTree as ET
import pprint
import collections

osm_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\new-delhi_india.osm'         # original dataset take from open street map
sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\sample.osm'               # sample file with a portion of data set
small_sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\small_sample.osm'   # a smaller sample file for testing purposes

def count_child_tags(filename):
        child_tags={}                                                           # to count unique child tags
        max_tag=(None,0)                                                        # to find the most popular k,v pair
        tag_k={}                                                                # to count key,value pairs
        with open(filename,'r') as f:
            for event,element in ET.iterparse(f):
                for child in iter(element):
                    if('k' in child.attrib):
                        if(child.attrib['k'] in tag_k):
                            tag_k[child.attrib['k']]+=1                         # counting the unique child tags
                        else:
                            tag_k[child.attrib['k']]=1

                    if(child.tag in child_tags):
                        child_tags[child.tag]+=1
                    else:
                        child_tags[child.tag]=1
                #element.clear()                                                # we won't use clear()
                                                                                # (used to keep the memory free for dataset)
                                                                                # because we also want to
                                                                                # find the most popular key value pair

            print 'The unique child tags in the given sample portion of dataset are :'
            pprint.pprint(child_tags)                                           # pretty prints all the unique
            print '\n'                                                          # child tags with their count
            from operator import itemgetter
            max_v=0
            print 'These are the keys and values of "tag" child in the header elements sorted as per their frequency:'

            for k, v in sorted(tag_k.items(), key=itemgetter(1)):               # prints sorted key,value pairs in the file,
                if(v>max_v):                                                    # sorted in ascending order
                    max_v=v                                                     # on the basis of number of times
                    max_tag=k,v                                                 # they occur in the file.
                    print (k,v)

            print '\n The most popular child tag is :- ',max_tag
        return child_tags,max_tag                                               # returns a tuble of all unique child
                                                                                # tags and the most popular key,value pair


with open('unique_child_tags_output.txt','w') as f:
    f.write('Unique child tags in small sample file : \n\n')                    # writing the child tags and most popular
    all_child_tag,max_tag=count_child_tags(small_sample_file)                   # key, value pair in output file
    f.write('\nThe most popular (key, value) child tag is :- \n')               # for sample, smaller sample, and original data set
    f.write(str(max_tag))                                                       # files.
    f.write('\n\nAll unique child tags are :- \n')
    f.write(str(all_child_tag))

    f.write('\n\nUnique child tags in sample file : \n\n')
    all_child_tag,max_tag=count_child_tags(sample_file)
    f.write('\nThe most popular (key, value) child tag is :- \n')
    f.write(str(max_tag))
    f.write('\n\nAll unique child tags are :- \n')
    f.write(str(all_child_tag))

    f.write('\n\nUnique child tags in original dataset file : \n\n')
    all_child_tag,max_tag=count_child_tags(osm_file)
    f.write('\nThe most popular (key, value) child tag is :- \n')
    f.write(str(max_tag))
    f.write('\n\nAll unique child tags are :- \n')
    f.write(str(all_child_tag))
