This project is a submission for the Data Wrangling OpenStreetMap Project.
All the code is sorted in different folders that are named accordingly, 
with each folder containing the python file and the output file.

I have removed the original osm file from the project 
because it was too large to submit the project(with the osm file),to download the original osm file please go to:
https://mapzen.com/data/metro-extracts/metro/new-delhi_india/


The text files and final project submission report are in a seperate folder and the data set 
and it's samples are in a seperate folder named as per their size.