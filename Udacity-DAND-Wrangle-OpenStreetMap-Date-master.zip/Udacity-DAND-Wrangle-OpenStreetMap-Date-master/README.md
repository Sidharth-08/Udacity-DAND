# Udacity DAND Wrangle OpenStreetMap Date

#### Map Area: New Delhi, India

We have used metro extract for Delhi because it's the capital city of India and very much populated and developing everyday, a never sleeping city which is large enough to give us some considerable outcomes and I know this because during my graduation i lived in the city for 4 years , so it'll be interesting to know if the results come out as expected or any different and is it documented in open street map as observed from the streets or any improvement is needed in the dataset. 

[Link to osm database](https://www.openstreetmap.org/relation/2763541)

[Download data](https://mapzen.com/data/metro-extracts/metro/new-delhi_india/)

The osm data consists of 'nodes' and 'ways' and many other associated tags. We will first analyze the dataset and make it ready to feed it into our database after which we will move towards querying the database.



Main project report is at the location:

`Udacity-DAND-Wrangle-OpenStreetMap-Date/9. Final_Project_Report_and_text_files/osm_project_submission.pdf`
