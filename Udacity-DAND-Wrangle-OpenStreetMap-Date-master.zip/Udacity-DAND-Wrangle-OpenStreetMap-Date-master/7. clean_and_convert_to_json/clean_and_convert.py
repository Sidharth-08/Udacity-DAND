import xml.etree.cElementTree as ET
import pprint
import re
import codecs
import json

osm_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\new-delhi_india.osm'         # original dataset take from open street map
sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\sample.osm'               # sample file with a portion of data set
small_sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\small_sample.osm'   # a smaller sample file for testing purposes


import sys
sys.path.insert(0, r'C:\Users\Sidharth-PC\Desktop\case1\6. audit_fields')
import audit_file                                                               # the audit_file in which various fields are audited
                                                                                # is imported here to use it's functions for
lower = re.compile(r'^([a-z]|_)*$')                                             # smooth processing of file.
lower_colon = re.compile(r'^([a-z]|_)*:([a-z]|_)*$')
double_colon= re.compile(r'^([a-z]|_)*:([a-z]|_)*:([a-z]|_)*$')                 # fields containing more than one " : "
problemchars = re.compile(r'[=\+/&<>;\'"\?%#$@\,\. \t\r\n]')

CREATED = [ "version", "changeset", "timestamp", "user", "uid"]


def shape_element(element):
    node = {}
    if element.tag == "node" or element.tag == "way" :
        node['id']=element.attrib['id']
        node['type']=element.tag
        if('visible' in element.attrib):
            node['visible']=element.attrib['visible']
        else:
            node['visible']=False
        created_f={}
        for creat in CREATED:
            created_f[creat]=element.attrib[creat]
        node['created']=created_f
        if(element.tag == 'node'):
            node['pos']=[float(element.attrib['lat']),float(element.attrib['lon'])]
        node_refs_f=[]
        address={}
        ad_sub={}
        for child in element:
            if(child.tag=='tag'):
                if(audit_file.is_garbage_value(child.attrib['v'])):
                    continue
                m=problemchars.search(child.attrib['k'])
                g=double_colon.search(child.attrib['k'])
                if not m and not g:

                    if('amenity' in child.attrib):
                        node['amenity']=child.attrib['amenity']
                    if("cuisine" in child.attrib):
                        node['cuisine']=child.attrib['cuisine']
                    if("name" in child.attrib):
                        node["name"]=child.attrib["name"]
                    if("phone" in child.attrib):
                        node["phone"]=child.attrib["phone"]

                    colon=lower_colon.search(child.attrib['k'])
                    if colon:                                                   # here care has been taken to ensure all the
                        dicto_list=child.attrib['k'].split(':',1)               # valid fields are entered into database even
                        dicto_name=dicto_list[0]                                # if not listed here.for example: fields such
                        ad_sub[dicto_list[1]]=child.attrib['v']                 # as 'Building' will be entered into database
                        if(dicto_name == 'addr'):                               # automatically with this code.
                            address[dicto_list[1]]=child.attrib['v']
                            node['address']=address
                        else:
                            node[dicto_name]=ad_sub

            if(child.tag=='nd'):
                node_refs_f.append(child.attrib['ref'])
        if(element.tag=='way'):
            node['node_refs']=node_refs_f

        return node
    else:
        return None


def process_map(file_in, pretty = False):
    file_out = "clean_and_convert_output.json".format(file_in)                  # the json file for mongoimport
    data = []
    with codecs.open(file_out, "w") as fo:
        for _, element in ET.iterparse(file_in):
            el = shape_element(element)
            if el:
                data.append(el)
                if pretty:
                    fo.write(json.dumps(el, indent=2)+"\n")

                else:
                    fo.write(json.dumps(el) + "\n")
    return data


def test():
    # NOTE: if you are running this code on your computer, with a larger dataset,
    # call the process_map procedure with pretty=False. The pretty=True option adds
    # additional spaces to the output, making it significantly larger.

    data = process_map(sample_file, True)                                       # doing this only for sample dataset, although
                                                                                # experiments have been done on other files.
                                                                                # point to be noted 'size of sample file > 50 mb'


if __name__ == "__main__":                                                      # taking the structure of file from
    test()                                                                      # the osm case study
