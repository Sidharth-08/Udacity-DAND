import xml.etree.cElementTree as ET
import pprint
import collections
"""
Your task is to explore the data a bit more.
The first task is a fun one - find out how many unique users
have contributed to the map in this particular area!

The function process_map should return a set of unique user IDs ("uid")
"""

osm_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\new-delhi_india.osm'         # original dataset take from open street map
sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\sample.osm'               # sample file with a portion of data set
small_sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\small_sample.osm'   # a smaller sample file for testing purposes

def get_unique_user(filename):
    users = set()
    for _, element in ET.iterparse(filename):
        if('uid'in element.attrib):
            users.add(element.attrib['uid'])                                    #element.clear() used to keep the memory free
        element.clear()
    print'Total unique users : ',len(users)
    pprint.pprint(users)
    return len(users)



with open('find_unique_users_output.txt','w') as f:
    f.write('Total number of Unique Users in small sample file : \n\n')         # write output to text files
    f.write(str(get_unique_user(small_sample_file)))
    f.write('\n\nTotal number of Unique Users in sample file : \n\n')
    f.write(str(get_unique_user(sample_file)))
    f.write('\n\nTotal number of Unique Users in original dataset file : \n\n')
    f.write(str(get_unique_user(osm_file)))
