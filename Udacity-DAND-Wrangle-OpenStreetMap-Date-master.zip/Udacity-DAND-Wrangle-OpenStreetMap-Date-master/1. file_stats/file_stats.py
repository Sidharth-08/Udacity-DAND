import os
import pprint

#filenames represents the storage path of file in this device

osm_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\new-delhi_india.osm'         # original dataset take from open street map
sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\sample.osm'               # sample file with a portion of data set
small_sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\small_sample.osm'   # a smaller sample file for testing purposes

statinfo=os.stat(osm_file)                                                 # os.stat gives us valuable information about filenames
statinfo_sample=os.stat(sample_file)                                       # like file size, last modified information and much more.
statinfo_small_sample=os.stat(small_sample_file)

with open('file_stats_output.txt','w') as f:
    f.write('Information for original dataset : \n\n')
    f.write(str(statinfo))                                                 # pprint is used to make print more orderly and in a
    f.write('\nInformation for sample of dataset : \n\n')                  # structural manner, so that it is easy to read.
    f.write(str(statinfo_sample))
    f.write('\nInformation for a much smaller sample of dataset : \n\n')
    f.write(str(statinfo_small_sample))
