'''
Your task is to use the iterative parsing to process the map file and
find out not only what tags are there, but also how many, to get the
feeling on how much of which data you can expect to have in the map.
Fill out the count_tags function. It should return a dictionary with the
tag name as the key and number of times this tag can be encountered in
the map as value.

Note that your code will be tested with a different data file than the 'example.osm'
'''
import xml.etree.cElementTree as ET
import pprint
import collections

osm_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\new-delhi_india.osm'         # original dataset take from open street map
sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\sample.osm'               # sample file with a portion of data set
small_sample_file=r'C:\Users\Sidharth-PC\Desktop\case1\0. data_sets\small_sample.osm'   # a smaller sample file for testing purposes

def count_tags(filename):
        tags={}                                                     # dictionary to keep cout of tags
        with open(filename,'r') as f:
            for event,element in ET.iterparse(f):                   # using iterparse for counting dataset due to large size
                if(element.tag in tags):
                    tags[element.tag]+=1
                else:
                    tags[element.tag]=1
                element.clear()                                     # after element is counted,
        return tags                                                 # it'll be cleared from memory to make
                                                                    # space due to large size of dataset


with open('unique_header_tags_output.txt','w') as f:
    f.write('Unique tags in small sample file : \n\n')              # write output to text files
    f.write(str(count_tags(small_sample_file)))
    f.write('\n\nUnique tags in sample file : \n\n')
    f.write(str(count_tags(sample_file)))
    f.write('\n\nUnique tags in original dataset file : \n\n')
    f.write(str(count_tags(osm_file)))
