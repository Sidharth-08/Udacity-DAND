# Udacity-Diamonds-Prices-Prediction
Analysis and prediction of Diamonds Prices using EDA.

Here we attempt to deduce the factors that go into the price of a diamonds.Socio-Economic and Political history of diamonds industry is fascinating. Diamonds gave rise to mining industry in south Africa. Diamonds were the reason of the colonization of South Africa and both historical and mordern wars and unrest in the region.

Please note **R studio** will be needed to view the project file.

`
main project file - lesson6_student.rmd
`
