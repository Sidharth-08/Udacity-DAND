The code for classifier is in file - poi_id.py
AdaBoost machine learning algorithm is used for the classifier.

The code for evaluation is in file - tester.py
StratifiedKFold cross-validation method is used for the validation purposes of the classifier.