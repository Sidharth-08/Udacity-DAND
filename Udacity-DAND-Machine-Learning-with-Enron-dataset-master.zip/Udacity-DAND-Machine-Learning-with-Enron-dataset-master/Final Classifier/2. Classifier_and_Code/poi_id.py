#!/usr/bin/python

import sys
import pickle
import pandas as pd
import numpy as np
sys.path.append("../tools/")

from feature_format import featureFormat, targetFeatureSplit
from tester import dump_classifier_and_data
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import AdaBoostClassifier




'''
function to calculate the fraction of two features(or any two numbers)
'NaNNaN' occurred when added two features.
Used in feature creation to find out the proportion of email sent between POI
and employee(dataitem).
'''
def fraction(x,y):
    if y == 'NaNNaN':
        return 0
    if x == 'NaNNaN':
        return 0
    if y == 'NaN':
        return 0
    if x == 'NaN':
        return 0
    if y == 0:
        return 0
    return float(x)/float(y)

################################################################################

### Task 1: Select what features you'll use.
### features_list is a list of strings, each of which is a feature name.
### The first feature must be "poi".

'''
Now out of these feature values, I have manually removed

[from_messages, from_poi_to_this_person, from_this_person_to_poi,to_messages]

from the final features list as these features have been used to create new
features which will be more effective than these features on their own.
Other features such as "director_fees" although included in the initial features
list will be removed as we move forward because
thay have more than half the values marked as NaN.
'''
features_list = ['poi', 'salary', 'deferral_payments', 'total_payments',
                 'loan_advances', 'bonus', 'restricted_stock_deferred',
                 'deferred_income', 'total_stock_value', 'expenses',
                 'exercised_stock_options',  'other','long_term_incentive',
                 'shared_receipt_with_poi',  'director_fees']

### Load the dictionary containing the dataset
with open("final_project_dataset.pkl", "r") as data_file:
    data_dict = pickle.load(data_file)

'''
Removing unnessesery features, that is the features with more
than half of the values missing or inconsistent.
'''

df = pd.DataFrame.from_records(list(data_dict.values()))
df.replace(to_replace='NaN',value=np.nan, inplace=True )
nan_features = []
features = df.axes[1].tolist()

for index,i in enumerate(df.isnull().sum()):
    if(i >= 70):
        nan_features.append(features[index])

print 'The list of not usable features is: ',nan_features

for feature in features_list:
    if(feature in nan_features):
        features_list.remove(feature)


# Also, email_address feature will be removed due to lack of practical usage,
# as each person has a unique email address and there won't be any pattern in
# the email addresses of POIs.
if('email_address' in features_list):
    features_list.remove('email_address')

################################################################################

### Task 2: Remove outliers

# 'TOTAL' is a spreadsheet extension
data_dict.pop('TOTAL',0)


# poping the names about whome we have no information available in the database.
useless_datapoints=[]
flag=0
for name in data_dict:
    flag=0
    for feature in data_dict[name]:
        if(data_dict[name][feature] != 'NaN' and data_dict[name][feature] != '' and feature != 'poi'):
            flag=1
    if(flag==0):
        useless_datapoints.append(name)
print 'Person for whom we have no information: ',useless_datapoints

if(len(useless_datapoints)>0):
    for item in useless_datapoints:
        data_dict.pop(item,0)

################################################################################

### Task 3: Create new feature(s)


my_data_dict = dict()
my_data_dict = data_dict

for name in my_data_dict:

    poi_msg_to = my_data_dict[name]['from_poi_to_this_person']
    all_msg_to = my_data_dict[name]['to_messages']
    my_data_dict[name]['fraction_from_poi'] = fraction(poi_msg_to,all_msg_to)

    poi_msg_from = my_data_dict[name]['from_this_person_to_poi']
    all_msg_from = my_data_dict[name]['from_messages']
    my_data_dict[name]['fraction_to_poi'] = fraction(poi_msg_from,all_msg_from)

    salary_emp = my_data_dict[name]['salary']
    total_payments_emp = my_data_dict[name]['total_payments']
    my_data_dict[name]['fraction_salary_total_payments'] = fraction(salary_emp,total_payments_emp)



### Store to my_dataset for easy export below.
my_dataset = my_data_dict

print 'Final features list: ',features_list

### Extract features and labels from dataset for local testing
data = featureFormat(my_dataset, features_list, sort_keys = True)
labels, features = targetFeatureSplit(data)

################################################################################

### Task 4: Try a varity of classifiers
### Please name your classifier clf for easy export below.
### Note that if you want to do PCA or other multi-stage operations,
### you'll need to use Pipelines. For more info:
### http://scikit-learn.org/stable/modules/pipeline.html

# Provided to give you a starting point. Try a variety of classifiers.

'''
Here, we have initialized the classifiers of various machine learning algorithm
so that we can use any of the following as our classifier and all we have to do
is to assign clf = CLASSIFIER
'''
'''
from sklearn.naive_bayes import GaussianNB                                      # accuracy = 0.466
nb = GaussianNB()

from sklearn.svm import SVC                                                     # accuracy = 0.482
svc = SVC()

from sklearn.tree import DecisionTreeClassifier                                 # accuracy(default parameters) = 0.63
dt = DecisionTreeClassifier(criterion = 'entropy',splitter = 'best')            # accuracy(with criterion = entropy) = 0.78


from sklearn.ensemble import RandomForestClassifier                             # accuracy = 0.56850
random_forest = RandomForestClassifier()


from sklearn.ensemble import BaggingClassifier                                  # accuracy = 0.55850
bagging = BaggingClassifier()

from sklearn.ensemble import AdaBoostClassifier                                 # Accuracy: 0.83480(with scaling and pca)
adaboost = AdaBoostClassifier()                                                 # Accuracy: 0.86080(without scaling and pca)
                                                                                # Accuracy: 0.84933(edit features)
                                                                                # Accuracy: 0.82020(no new features)



from sklearn.cluster import KMeans                                              # accuracy = 0.53
km = KMeans()
'''

'''
to do experimentation with scaling and pca
with different machine learning algorithm
classifiers initialized above.

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
scaler = MinMaxScaler()
clf = Pipeline(steps=[('scale_features',scaler),('pca',PCA(n_components=5)),('km',km)])
'''

################################################################################

### Task 5: Tune your classifier to achieve better than .3 precision and recall
### using our testing script. Check the tester.py script in the final project
### folder for details on the evaluation method, especially the test_classifier
### function. Because of the small size of the dataset, the script uses
### stratified shuffle split cross validation. For more info:
### http://scikit-learn.org/stable/modules/generated/sklearn.cross_validation.StratifiedShuffleSplit.html

'''
to check for parameter tuning for other machine learning algorithms
 -> Support Vector Machines
 -> Decision Trees

parameters_svc = {'kernel':('linear', 'rbf'), 'C':[1, 10]}
parameters_dt = {'criterion':('entropy', 'gini'),'splitter':('best','random')}
'''


'''
# tuning the adaboost classifier for the optimal results.
num_iteration = [100,300,500,850,1000,2000,5000]
learning = [0.01, 0.1, 0.6, 1.0, 1.5, 2.0]
parameters_adaboost = {'n_estimators':num_iteration,'learning_rate':learning,'algorithm':['SAMME.R','SAMME']}
clf = GridSearchCV(adaboost, parameters_adaboost)
'''


# to check the performance of algorithm in their default
# parameters setting using the classifiers initialized above.
# clf = dt

# After our experimentation with GridSearchCV
clf = AdaBoostClassifier(n_estimators = 1000, learning_rate = 1.0, algorithm = 'SAMME.R',random_state = 100)

################################################################################

### Task 6: Dump your classifier, dataset, and features_list so anyone can
### check your results. You do not need to change anything below, but make sure
### that the version of poi_id.py that you submit can be run on its own and
### generates the necessary .pkl files for validating your results.

dump_classifier_and_data(clf, my_dataset, features_list)
