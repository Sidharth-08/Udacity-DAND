# Udacity DAND Machine Learning with Enron dataset

Enron, popularly known as an energy company in United States, 7th on the Fotune 500 list in year 2000 and bankrupt by the January of 2002 was one of the largest companies ever to exist in united States that went down as a result of widespread corporate fraud. As a result of such a scandal at a wall street darling company the Federal Investigation of all the confidential information containing the email records and financial records of the Enron employees lead to data going in public domain.

In our investigation, we have attempted to use our machine learning skills to build a person of interest identifier based on financial and email data made public as a result of the Enron scandal.
