# Udacity-DAND-EDA

A nice glass of high quality wine always puts a smile on our face, but how do we know the difference in quality of so many wines available in the market, maybe we can find a relation between the chemicals used in making the wine and it’s quality. Therefore, An attempt has been made here to explore the relation between the quality of a red wine and the ratio of chemicals used in the manufacturing process. 
